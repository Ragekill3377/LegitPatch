//
// Created By Ragekill3377. 7/10/24
//

/*

FYI: This is the LegitServer anti-inject bypass, written by Ragekill3377.

How It Works: 
LegitServer has an anti-cheat component within it, which checks for injected libraries within ARK.
It utilizes '_dyld_image_count()' to retrieve the number of loaded images, besides itself in the app.
You can see this check in the 'LegitDecompileDecrypted/dump.c' of LegitServer and understand how it works.
Basically, if the image-count > 0, it means someone has inject a dynamic library in the app, which is usually a cheat, and thus it detects it and bans the cheater.  But, since Carson is a nigger and I don't want to see LegitServers peaceful, I made this 'bypass'.
It uses fishhook to 'hook' _dyld_image_count, and make it return 0.
I've also used attributes for this. ( Attributes make sure your code runs before ANYTHING else ).
Now what does that do?
Back to the statement:
if the image-count > 0, it means someone has inject a dynamic library.
But, with our hook, the image count will always avail 0.
0 is not greater than 0.
That turns the if statement to false.
Thus, it doesn't flag our loaded dynamic library.

That's 1 detection bypassed. Carnigger has another thing aswell. But, I was ready for it
Simple asf.
uVar4 = _objc_msgSend(lVar3,"containsString:",&cf__dylib);
See that line? He just checks the app's main bundle for extra .dylib extensions, besides his own and libsubstrate ofc.
So, what's the fix?
We hook 'containsString', and make it return no.
That's all, you can see the code below.
Now all that is done...
Yay! you've got past anti-code-injection on LegitServer.
Update: LegitServer 2..3.b8 or something idk. LegitServer was updated, and now this doesn't work entierly. You can get banned, but just build on it from here. Good Luck.
You could use libhooker if you want. I'd stick with substrate.

discord: ragekill_3377
Github: https://github.com/Ragekill3377

APIs used: mobilesubstrate (Formerly Cydia-Substrate) & fishhook, by meta.

*/

#import <Foundation/Foundation.h>
#include <stdio.h>
#include <mach-o/dyld.h>
#include "fishhook/fishhook.h"
#include <objc/runtime.h>
#include <objc/message.h>
#include <substrate.h>


// our orig funcs.
static uint32_t (*orig_dyld_get_image_count)(void);
static BOOL (*orig_containsString)(id self, SEL _cmd, NSString *substring);
static BOOL (*orig_writeToFile)(id self, SEL _cmd, NSString *path, BOOL atomically, NSStringEncoding encoding, NSError **error);
static void (*orig_abort)(void);
static void (*orig_exit)(int status);

// hooked funcs. These will be our own implementations.
uint32_t my_dyld_get_image_count(void) {
    return 0;
}

// This can be a bit 'variable'. If the app has a check like this and has its own dylibs it depends on, whitelist those/filter them out.
BOOL my_containsString(id self, SEL _cmd, NSString *substring) {
    if ([substring isEqualToString:@".dylib"] || [substring isEqualToString:@"dylib"]) {
        return NO;
    }
    return orig_containsString(self, _cmd, substring);
}

// you can change the content here. if such content is detected, auto block Write to file.
BOOL my_writeToFile(id self, SEL _cmd, NSString *path, BOOL atomically, NSStringEncoding encoding, NSError **error) {
    NSString *content = [self stringByAppendingString:path];
    if ([content containsString:@"fuck"] || [content containsString:@"fuck you"]) {
        NSLog(@"[HOOK]: No Erasy-Erasy!!!");
        return NO;
    }
    return orig_writeToFile(self, _cmd, path, atomically, encoding, error);
}

// abort & exit. Both can be used to terminate a process. These were hooked, so that even if the app detects something, it won't exit, if it crashes via these.
void my_abort(void) {
    return;
}

void my_exit(int status){
    return;
}

__attribute__((constructor))
static void init_hooks(void) {
    /* HOOKS */
    struct rebinding rebindings[] = {
        {"_dyld_image_count", (void *)my_dyld_get_image_count, (void **)&orig_dyld_get_image_count},
        {"abort", (void *)my_abort, (void **)&orig_abort},
        {"exit", (void *)my_exit, (void **)&orig_exit}
    };
    rebind_symbols(rebindings, 3);

    // substrate hooks for objc funcs. yes, works on jailed / non-jb. as long as substrate is loaded.
    Class NSStringClass = objc_getClass("NSString");
    MSHookMessageEx(NSStringClass, @selector(containsString:), (IMP)my_containsString, (IMP *)&orig_containsString);

    MSHookMessageEx(NSStringClass, @selector(writeToFile:atomically:encoding:error:), (IMP)my_writeToFile, (IMP *)&orig_writeToFile);
}
